Used to help ignore the compilation errors in VSCode

DO NOT IMPORT INTO THE RASPBERRY PI ITSELF.